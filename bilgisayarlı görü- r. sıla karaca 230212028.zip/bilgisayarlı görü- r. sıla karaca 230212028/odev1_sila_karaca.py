# =============================================================================
# YZM 411 – Bilgisayarlı Görü  |  Ödev #1: Renk, Aydınlatma, Örnekleme
# Öğrenci : Sıla Karaca  |  No: 230212028
#
# Çalıştırma: Bu betiği fotoğraflarla aynı klasöre koyun ve çalıştırın.
#   > python odev1_sila_karaca.py
#
# Gereksinimler: opencv-python, numpy
#   > pip install opencv-python numpy
# =============================================================================

import cv2
import numpy as np
import os

# ---------------------------------------------------------------------------
# Yardımcı: bölüm başlığı yazdır
# ---------------------------------------------------------------------------
def baslik(no, metin):
    print("\n" + "=" * 65)
    print(f"  ADIM {no}: {metin}")
    print("=" * 65)

# ---------------------------------------------------------------------------
# Yardımcı: çalışma dizini doğrulama
# ---------------------------------------------------------------------------
CALISMA_DIZINI = os.path.dirname(os.path.abspath(__file__))
os.chdir(CALISMA_DIZINI)

DOSYALAR = {
    "normal": "normal.jpeg",
    "golge" : "golge.jpeg",
    "lamba" : "lamba.jpeg",
}

# ===========================================================================
# ADIM 4 – Görüntü Okuma ve Temel Özellikler
# ===========================================================================
baslik(4, "GÖRÜNTÜ OKUMA VE TEMEL ÖZELLİKLER")

print("""
[TAHMİN] Üç fotoğrafın da boyutu yaklaşık olarak benzer olmalı; ancak aynı değil.
[TAHMİN] JPEG formatı nedeniyle dtype uint8 ve değer aralığı [0, 255] olacak.
""")

goruntular = {}   # {ad: rgb_array}

for ad, dosya in DOSYALAR.items():
    bgr = cv2.imread(dosya)
    if bgr is None:
        print(f"  [HATA] '{dosya}' okunamadı! Betikle aynı klasörde mi?")
        raise FileNotFoundError(f"{dosya} bulunamadı.")
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    goruntular[ad] = rgb
    h, w, c = rgb.shape
    print(f"  [{ad.upper():6s}]  Boyut: {h} × {w} × {c}  |  dtype: {rgb.dtype}"
          f"  |  min: {rgb.min():3d}  max: {rgb.max():3d}")

print("""
[GÖZLEM] Fotoğrafların yükseklikleri aynı (1600 px), genişlikleri farklı
          (normal: 918, gölge: 970, lamba: 1038). Bu, el kamerasında kırpma/
          açı farkından kaynaklanmaktadır. dtype=uint8, aralık [0,255] beklendi → doğrulandı.
""")

# ===========================================================================
# ADIM 4b – Aynı Fiziksel Bölgeden Piksel Karşılaştırması
# ===========================================================================
print("-" * 65)
print("  ADIM 4b: Aynı Fiziksel Bölge — Sarı Defterin Merkezi")
print("-" * 65)

print("""
[TAHMİN] Normal ışıkta sarıya özgü yüksek R, orta G, düşük B görmeliyiz.
[TAHMİN] Gölgede tüm kanallar çok düşük olacak; lambada kırmızı ağırlıklı kayma bekliyorum.
""")

# Oransal koordinat (normal: %46,8 x, %59,4 y → sarı defterin merkezi)
# normal: (430, 950), golge: (454, 950), lamba: (486, 950)
koordinatlar = {}
oran_x, oran_y = 0.468, 0.594
for ad, rgb in goruntular.items():
    h, w = rgb.shape[:2]
    koordinatlar[ad] = (int(oran_x * w), int(oran_y * h))

print(f"  {'Fotoğraf':<8} {'Koordinat':<14} {'R':>5} {'G':>5} {'B':>5}")
print(f"  {'-' * 44}")
for ad, (x, y) in koordinatlar.items():
    rgb = goruntular[ad]
    r, g, b = int(rgb[y, x, 0]), int(rgb[y, x, 1]), int(rgb[y, x, 2])
    print(f"  {ad:<8} ({x:4d},{y:4d})    {r:5d} {g:5d} {b:5d}")

print("""
[GÖZLEM] normal: R=206 G=187 B=92  → R>G>>B → sarı renk doğrulandı.
          golge : R=47  G=46  B=42  → tüm kanallar düşük (~45) → parlaklık kaybı.
          lamba : R=240 G=149 B=156 → R>>G≈B → kırmızı/amber kayma (pembe ton).
""")

# ===========================================================================
# ADIM 5 – Renk Eşikleme ve Maske Üretimi
# ===========================================================================
baslik(5, "RENK EŞİKLEME – MASKE ÜRETİMİ")

print("""
[TAHMİN] Normal fotoğrafa uyarlanmış HSV eşiği, gölgede 0 piksel bulacak.
[TAHMİN] Lamba görüntüsünde HSV ton kaymasından dolayı başarı düşük olacak.
""")

# Sarı defter pikseli: RGB(206,187,92) → HSV(H=25, S=141, V=206)  [OpenCV ölçeği]
# SABİT EŞİK — üç fotoğrafa da değiştirilmeden uygulanır
HSV_ALT = np.array([15,  80,  80], dtype=np.uint8)
HSV_UST = np.array([35, 255, 255], dtype=np.uint8)

print(f"  Sarı eşiği: HSV_alt = {HSV_ALT.tolist()}  |  HSV_ust = {HSV_UST.tolist()}")
print(f"  Beyaz kağıt eşiği: RGB tüm kanallar > 180\n")

# Tablo başlığı
print(f"  {'Fotoğraf':<8} {'Toplam px':>12} {'Sarı px':>10} {'Sarı%':>7}"
      f"  {'Kağıt px':>10} {'Kağıt%':>7}")
print(f"  {'-' * 60}")

for ad, rgb in goruntular.items():
    # HSV dönüşümü
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)

    # Sarı maske
    maske_sari  = cv2.inRange(hsv, HSV_ALT, HSV_UST)
    # Beyaz kağıt maskesi
    kag_alt = np.array([180, 180, 180], dtype=np.uint8)
    kag_ust = np.array([255, 255, 255], dtype=np.uint8)
    maske_kag   = cv2.inRange(rgb, kag_alt, kag_ust)

    toplam      = maske_sari.size
    sari_say    = int(np.sum(maske_sari  > 0))
    kag_say     = int(np.sum(maske_kag   > 0))
    sari_oran   = sari_say / toplam * 100
    kag_oran    = kag_say  / toplam * 100

    # Kaydet
    cv2.imwrite(f"adim5_maske_sari_{ad}.png",  maske_sari)
    cv2.imwrite(f"adim5_maske_kagit_{ad}.png", maske_kag)

    print(f"  {ad:<8} {toplam:>12,} {sari_say:>10,} {sari_oran:>7.2f}%"
          f"  {kag_say:>10,} {kag_oran:>7.2f}%")

print("""
[GÖZLEM] Gölge: sarı maske = 0 piksel. V değeri (~47) eşik alt sınırı 80'in altında.
          Lamba: sarı maske başarısız; H=178 (mavi-yeşil bölge) eşik [15,35] dışında.
          HSV eşiği aydınlatma-renk bağımsızlığı sağlamaz; sadece parlaklık toleransı verir.
""")

# ===========================================================================
# ADIM 6 – Parlaklık Kaydırması ve Gamma Dönüşümü
# ===========================================================================
baslik(6, "PARLAKLIKLARI DEĞİŞTİRME")

print("""
[TAHMİN] b=+40 kaydırması: yüksek değerli pikseller 255'e yapışacak (kırpılma).
[TAHMİN] gamma=0.5 (açma): karanlık pikseller belirgin artar, kırpma olmaz.
[TAHMİN] gamma=2.0 (koyultma): aydınlık pikseller koyulaşır, kırpma olmaz.
""")

img_n   = goruntular["normal"].astype(np.float64)   # float64 üzerinde çalış
ort_orj = img_n.mean()

# --- 6.1 Parlaklık Kaydırması b = +40 ---
b = 40
kaydirilmis   = img_n + b
kirpilmis     = np.clip(kaydirilmis, 0.0, 255.0)
kac_kirpildi  = int(np.sum(kaydirilmis > 255.0))
ort_kaydirma  = kirpilmis.mean()

print(f"  Parlaklık Kaydırması (b = +{b})")
print(f"    Ortalama (önce)   : {ort_orj:.2f}")
print(f"    Ortalama (sonra)  : {ort_kaydirma:.2f}")
print(f"    Δ Ortalama        : {ort_kaydirma - ort_orj:+.2f}")
print(f"    Kırpılan piksel   : {kac_kirpildi:,} / {img_n.size:,} "
      f"({kac_kirpildi / img_n.size * 100:.2f}%)")
cv2.imwrite("adim6_brightness_b40.png",
            cv2.cvtColor(kirpilmis.astype(np.uint8), cv2.COLOR_RGB2BGR))

# --- 6.2 Gamma Dönüşümü ---
def uygula_gamma(img_float, gamma):
    """img_float: 0-255 float array → döndürür (uint8, ortalama, kırpılan_sayı)"""
    norm     = np.clip(img_float / 255.0, 0.0, 1.0)
    donusmus = np.power(norm, gamma) * 255.0
    kir      = int(np.sum(donusmus > 255.0))
    return donusmus.astype(np.uint8), float(donusmus.mean()), kir

for gamma in [0.5, 2.0]:
    don_uint8, ort_son, kir = uygula_gamma(img_n, gamma)
    print(f"\n  Gamma Dönüşümü (γ = {gamma})")
    print(f"    Ortalama (önce)   : {ort_orj:.2f}")
    print(f"    Ortalama (sonra)  : {ort_son:.2f}")
    print(f"    Δ Ortalama        : {ort_son - ort_orj:+.2f}")
    print(f"    Kırpılan piksel   : {kir}")
    isim = str(gamma).replace(".", "_")
    cv2.imwrite(f"adim6_gamma_{isim}.png",
                cv2.cvtColor(don_uint8, cv2.COLOR_RGB2BGR))

print("""
[GÖZLEM] b=+40: ortalama +34,76 arttı, ~148.000 piksel kırpıldı (ışıklı alanlar).
          γ=0.5: ortalama +37,11 arttı, kırpma = 0 (güç fonk. [0,1]→[0,1] garantisi).
          γ=2.0: ortalama -50,32 düştü, kırpma = 0 (aydınlık bölgeler koyulaştı).
          Tutmayan tahmin: γ=0.5 artışı b=+40'tan fazla çıktı; nonlineer etki.
""")

# ===========================================================================
# ADIM 7 – Örnekleme / Yeniden Boyutlandırma
# ===========================================================================
baslik(7, "ÖRNEKLEME – YENİDEN BOYUTLANDIRMA")

print("""
[TAHMİN] INTER_NEAREST 1/4 küçültmede pikselleri seçip attığından yazılar bloklaşacak.
[TAHMİN] INTER_AREA ortalamayla yumuşatacak; yazı daha az bloklu ama yine silik.
[TAHMİN] Her iki yöntemde de geri büyütme yazıyı geri getirmeyecek.
""")

# Yazılı defter bölgesi (normal fotoğraf): y:60-560, x:220-520
img_rgb = goruntular["normal"]
bolge   = img_rgb[60:560, 220:520].copy()   # 500 × 300 px

h_b, w_b = bolge.shape[:2]
w_k      = w_b // 4   # 75
h_k      = h_b // 4   # 125

print(f"  Orijinal bölge boyutu : {h_b} × {w_b} px")
print(f"  Hedef 1/4 boyutu      : {h_k} × {w_k} px\n")

for yad, ykod in [("INTER_NEAREST", cv2.INTER_NEAREST),
                   ("INTER_AREA",   cv2.INTER_AREA)]:
    # Küçült
    kucuk = cv2.resize(bolge, (w_k, h_k), interpolation=ykod)
    # Orijinal boyuta geri büyüt (INTER_NEAREST → bloklu fark)
    geri  = cv2.resize(kucuk, (w_b, h_b), interpolation=cv2.INTER_NEAREST)
    # Fark haritası
    fark  = np.abs(bolge.astype(np.int32) - geri.astype(np.int32))
    fark  = np.clip(fark, 0, 255).astype(np.uint8)
    ort_f = float(fark.mean())

    print(f"  Yöntem : {yad}")
    print(f"    1/4 küçük boyutu        : {kucuk.shape[1]} × {kucuk.shape[0]}")
    print(f"    Geri büyütülmüş boyutu  : {geri.shape[1]} × {geri.shape[0]}")
    print(f"    Ortalama piksel farkı   : {ort_f:.2f} / 255\n")

    cv2.imwrite(f"adim7_kucuk_{yad}.png",
                cv2.cvtColor(kucuk, cv2.COLOR_RGB2BGR))
    cv2.imwrite(f"adim7_geri_{yad}.png",
                cv2.cvtColor(geri,  cv2.COLOR_RGB2BGR))
    cv2.imwrite(f"adim7_fark_{yad}.png",
                cv2.cvtColor(fark,  cv2.COLOR_RGB2BGR))

print("""
[GÖZLEM] INTER_NEAREST farkı > INTER_AREA farkı → blok yapısı daha fazla sapma.
          Geri büyütme YENİ piksel bilgisi üretemez; kaybolan yazı geri gelmez.
          Nyquist-Shannon: ince yazı çizgileri yüksek-frekans bileşendir; 1/16
          örnekleme ile bu frekanslar kalıcı olarak atılır, kurtarma imkânsızdır.
""")

print("=" * 65)
print("  TÜM ADIMLAR TAMAMLANDI")
print("  Üretilen dosyalar bu klasörde 'adim5_', 'adim6_', 'adim7_' önekleriyle.")
print("=" * 65)
